clc;clear;
data = TDMS_getStruct('【声镊数据】100nM_FUS-GAL4_11xDBD.tdms');
F = data.g_1.Force__pN_.data;
x = data.g_1.Distance__um_.data;
f = data.g_1.Force__pN_.data;
para0=0;
ub=inf;
lb=-inf;
delta_x=lsqcurvefit(@wlc,para0,x,f,lb,ub);
f1=wlc(delta_x,x);
subplot(1,2,2)
plot(x,f1)
xlabel('x / \mu m');
ylabel('F / pN');
title('100nM\_FUS-GAL4\_11xDBD Worm-Like Chain Model')
legend('Worm-Like Chain Model')
subplot(1,2,1)
plot(x,F,'r');
xlabel('x / \mu m');
ylabel('F / pN');
title(['100nM\_FUS-GAL4\_11xDBD Experimental Data'])
legend('Experimental Data')



%%
clc;clear;
data = TDMS_getStruct('【声镊数据】100nM_FUS-GAL4_randomDNA.tdms');
F = data.g_1.Force__pN_.data;
x = data.g_1.Distance__um_.data;
f = data.g_1.Force__pN_.data;
para0=0;
ub=inf;
lb=-inf;
delta_x=lsqcurvefit(@wlc,para0,x,f,lb,ub);
f1=wlc(delta_x,x);
subplot(1,2,2)
plot(x,f1)
xlabel('x / \mu m');
ylabel('F / pN');
title('100nM\_FUS-GAL4\_random DNA Worm-Like Chain Model')

legend('Worm-Like Chain Model')
subplot(1,2,1)
plot(x,F,'r');
xlabel('x / \mu m');
ylabel('F / pN');
title(['100nM\_FUS-GAL4\_random DNA Experimental Data'])

legend('Experimental Data')
%%
clc;clear;
data = TDMS_getStruct('【声镊数据】naked_11xDBD.tdms');
F = data.g_1.Force__pN_.data;
x = data.g_1.Distance__um_.data;
f = data.g_1.Force__pN_.data;
para0=0;
ub=inf;
lb=-inf;
delta_x=lsqcurvefit(@wlc,para0,x,f,lb,ub);
f1=wlc(delta_x,x);
subplot(1,2,2)
plot(x,f1)
xlabel('x / \mu m');
ylabel('F / pN');
title('naked\_11xDBD Worm-Like Chain Model')
legend('Worm-Like Chain Model')
subplot(1,2,1)
plot(x,F,'r');
xlabel('x / \mu m');
ylabel('F / pN');
title(['naked\_11xDBD Experimental Data'])
legend('Experimental Data')



%% combine1
clc;clear;
data = TDMS_getStruct('【声镊数据】100nM_FUS-GAL4_11xDBD.tdms');
F = data.g_1.Force__pN_.data;
x = data.g_1.Distance__um_.data;
f = data.g_1.Force__pN_.data;
para0=0;
ub=inf;
lb=-inf;
delta_x=lsqcurvefit(@wlc,para0,x,f,lb,ub);
f1=wlc(delta_x,x);
plot(x,f1)
xlabel('x / \mu m');
ylabel('F / pN');
title('100nM\_FUS-GAL4\_11xDBD Worm-Like Chain Model')
hold on;
plot(x,F);
xlabel('x / \mu m');
ylabel('F / pN');
title(['100nM\_FUS-GAL4\_11xDBD Experimental Data'])
legend('Worm-Like Chain Model','Experimental Data')
hold off


%% combine2
clc;clear;
data = TDMS_getStruct('【声镊数据】100nM_FUS-GAL4_randomDNA.tdms');
F = data.g_1.Force__pN_.data;
x = data.g_1.Distance__um_.data;
f = data.g_1.Force__pN_.data;
para0=0;
ub=inf;
lb=-inf;
delta_x=lsqcurvefit(@wlc,para0,x,f,lb,ub);
f1=wlc(delta_x,x);
plot(x,f1)
xlabel('x / \mu m');
ylabel('F / pN');
title('100nM\_FUS-GAL4\_random DNA Worm-Like Chain Model')
hold on;
plot(x,F);
xlabel('x / \mu m');
ylabel('F / pN');
title('100nM\_FUS-GAL4\_random DNA Experimental Data')
legend('Worm-Like Chain Model','Experimental Data')
hold off


%% combine3
clc;clear;
data = TDMS_getStruct('【声镊数据】naked_11xDBD.tdms');
F = data.g_1.Force__pN_.data;
x = data.g_1.Distance__um_.data;
f = data.g_1.Force__pN_.data;
para0=0;
ub=inf;
lb=-inf;
delta_x=lsqcurvefit(@wlc,para0,x,f,lb,ub);
f1=wlc(delta_x,x);
plot(x,f1)
xlabel('x / \mu m');
ylabel('F / pN');
title('naked\_11xDBD Worm-Like Chain Model')
hold on;
plot(x,F);
xlabel('x / \mu m');
ylabel('F / pN');
title('naked\_11xDBD Experimental Data')
legend('Worm-Like Chain Model','Experimental Data')
hold off


